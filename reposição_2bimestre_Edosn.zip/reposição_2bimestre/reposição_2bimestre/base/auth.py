from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash
from flask import app

import database

app.config['SECRET_KEY'] = '12345'



auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/registro", methods=["GET", "POST"])
def registro():

    if 'user' in session:
        return redirect(url_for('login'))

    if request.method == "POST":

       nome=request.form.get('nome')
       email=request.form.get('email')
       senha=request.form.get('senha')
       hash = generate_password_hash(senha)
     

       

       flash("Complete o cadastro usando database.py e generate_password_hash.")
       return redirect(url_for("auth.registro"))

    return render_template("registro.html",nome=nome,email=email,senha=senha)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":

        if  not 'user' in session:
               return redirect(url_for('registro'))
       
        email=request.form.get('email')
        senha=request.form.get('senha')

        

        flash("Complete o login usando check_password_hash e session.")
        return redirect(url_for("auth.login"))

    return render_template("login.html",email=email,senha=senha)


@auth_bp.route("/logout")
def logout():

    session.pop('user', None)

    flash("Complete o logout removendo os dados da session.")
    return redirect(url_for("auth.login"))
